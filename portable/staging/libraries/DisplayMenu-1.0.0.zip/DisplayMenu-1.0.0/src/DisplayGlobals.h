
#ifndef DISPLAYGLOBAL_H
#define DISPLAYGLOBAL_H

enum DisplayState {
    VISABLE,
    HIDDEN
};

enum TextAlign {
    ALIGN_LEFT,
    ALIGN_CENTER,
    ALIGN_RIGHT
    
};

#endif