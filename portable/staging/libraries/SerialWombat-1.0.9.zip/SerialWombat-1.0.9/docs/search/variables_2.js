var searchData=
[
  ['errorcount_299',['errorCount',['../class_serial_wombat.html#ace39a99ea958ca2327b2cd6efa563bd1',1,'SerialWombat']]],
  ['errornum_300',['errorNum',['../class_serial_wombat.html#adacb25c6b8842a8f55fab0ad67ba573e',1,'SerialWombat']]]
];
