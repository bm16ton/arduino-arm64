var searchData=
[
  ['error_5fhost_5fdata_5ftoo_5flong_32',['ERROR_HOST_DATA_TOO_LONG',['../_serial_wombat_8h.html#a751cf6960a7a525a40e72e730daac9ae',1,'SerialWombat.h']]],
  ['error_5fhost_5fincorrect_5fnumber_5fbytes_5fwritten_33',['ERROR_HOST_INCORRECT_NUMBER_BYTES_WRITTEN',['../_serial_wombat_8h.html#a50a8540e467a4306be06008f624418ec',1,'SerialWombat.h']]],
  ['error_5fhost_5fnack_5faddress_34',['ERROR_HOST_NACK_ADDRESS',['../_serial_wombat_8h.html#aec408c516734ff7a2e0aed6211905e55',1,'SerialWombat.h']]],
  ['error_5fhost_5fnack_5fdata_35',['ERROR_HOST_NACK_DATA',['../_serial_wombat_8h.html#a399606dd6f8afb57bfcd4618ce65a12f',1,'SerialWombat.h']]],
  ['error_5fhost_5fother_5fi2c_5ferror_36',['ERROR_HOST_OTHER_I2C_ERROR',['../_serial_wombat_8h.html#a51cc362ad9d679b13bf72f80011b766d',1,'SerialWombat.h']]],
  ['errorcount_37',['errorCount',['../class_serial_wombat.html#ace39a99ea958ca2327b2cd6efa563bd1',1,'SerialWombat']]],
  ['errornum_38',['errorNum',['../class_serial_wombat.html#adacb25c6b8842a8f55fab0ad67ba573e',1,'SerialWombat']]]
];
