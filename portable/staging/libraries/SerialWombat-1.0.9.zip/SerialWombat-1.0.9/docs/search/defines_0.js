var searchData=
[
  ['error_5fhost_5fdata_5ftoo_5flong_380',['ERROR_HOST_DATA_TOO_LONG',['../_serial_wombat_8h.html#a751cf6960a7a525a40e72e730daac9ae',1,'SerialWombat.h']]],
  ['error_5fhost_5fincorrect_5fnumber_5fbytes_5fwritten_381',['ERROR_HOST_INCORRECT_NUMBER_BYTES_WRITTEN',['../_serial_wombat_8h.html#a50a8540e467a4306be06008f624418ec',1,'SerialWombat.h']]],
  ['error_5fhost_5fnack_5faddress_382',['ERROR_HOST_NACK_ADDRESS',['../_serial_wombat_8h.html#aec408c516734ff7a2e0aed6211905e55',1,'SerialWombat.h']]],
  ['error_5fhost_5fnack_5fdata_383',['ERROR_HOST_NACK_DATA',['../_serial_wombat_8h.html#a399606dd6f8afb57bfcd4618ce65a12f',1,'SerialWombat.h']]],
  ['error_5fhost_5fother_5fi2c_5ferror_384',['ERROR_HOST_OTHER_I2C_ERROR',['../_serial_wombat_8h.html#a51cc362ad9d679b13bf72f80011b766d',1,'SerialWombat.h']]]
];
