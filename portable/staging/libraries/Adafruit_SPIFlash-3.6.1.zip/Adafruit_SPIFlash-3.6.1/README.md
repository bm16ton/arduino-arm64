# Adafruit SPI Flash [![Build Status](https://travis-ci.com/adafruit/Adafruit_SPIFlash.svg?branch=master)](https://travis-ci.com/adafruit/Adafruit_SPIFlash)

for FAT filesystems on SPI flash chips.
