var searchData=
[
  ['deviceidentifier_289',['deviceIdentifier',['../class_serial_wombat.html#a5009ed40b7d8d2678a4e85deea88dda2',1,'SerialWombat']]],
  ['devicerevision_290',['deviceRevision',['../class_serial_wombat.html#aac98554ee951cbee87d18af0047981a2',1,'SerialWombat']]]
];
