var searchData=
[
  ['queryversion_233',['queryVersion',['../class_serial_wombat.html#a9de39b2b667e2d0b213d59f186fb2837',1,'SerialWombat']]]
];
