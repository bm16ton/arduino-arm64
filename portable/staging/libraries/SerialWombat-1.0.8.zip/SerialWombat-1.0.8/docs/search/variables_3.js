var searchData=
[
  ['fwversion_293',['fwVersion',['../class_serial_wombat.html#a04684dfecbef299dcf7e6d442dfda2c5',1,'SerialWombat']]]
];
