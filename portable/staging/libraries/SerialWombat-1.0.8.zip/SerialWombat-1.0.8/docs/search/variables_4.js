var searchData=
[
  ['highcounts_294',['HighCounts',['../class_serial_wombat_pulse_timer.html#aa6120417cebec86fd6966a2460f9d12d',1,'SerialWombatPulseTimer']]],
  ['highlimit_295',['highLimit',['../class_serial_wombat_button_counter.html#a5d70e0ffb4af29834193f0a0cbe0f54b',1,'SerialWombatButtonCounter']]]
];
