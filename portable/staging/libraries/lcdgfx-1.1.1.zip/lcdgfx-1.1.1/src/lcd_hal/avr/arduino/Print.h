#ifndef _PRINT_H_
#define _PRINT_H_

#include "../../io.h"
#include "../../Print_internal.h"

#define __FlashStringHelper char

#endif
