
/**
 * Class implements interface functions to ~CONTROLLER~ displays
 */
template <class I> class Interface~CONTROLLER~: public I
{
public:
~FUNCS_DECL~~FIELDS_DECL~
};
