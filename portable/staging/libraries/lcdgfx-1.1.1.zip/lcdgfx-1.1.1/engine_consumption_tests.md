# Memory consumption, based on Arduino Nano board

| **sketch** | **2.0.0 Flash** | **1.7.18 Flash** | **2.0.0 RAM** | **1.7.18 RAM** |
| :-------- |:---:|:---:|:---:|:---------|
| nano_engine/nano_engine | 8832 | 8804 | 663 | 693 |
| nano_engine/snowflakes | 8208 | 6310 | 725 | 818 |
| games/arkanoid8 | 11288 | 10940 | 692 | 708 |
| games/lode_runner | 11854 | 12176 | 1005  | 1017 |

