## Project Authors

* lcdgfx library is written by [Alexey Dynda](https://github.com/lexus2k). This is improved
  version of another C-style library [ssd1306](https://github.com/lexus2k/ssd1306)

## Contributors

* [MinusWall](https://github.com/minuswall)
* [drgallaci](https://github.com/drgallaci)
* [CromFr](https://gitbug.com/CromFr)
* [enekochan](https://github.com/enekochan)
