
# Arduino library for MERG CBUS running over CAN bus

This library contains an abstract base class that must be implemented by a concrete subclass, e.g. CBUS2515

## Hardware

## Documentation

See the documentation files and example sketch included with the CBUS2515 library

## License

Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
