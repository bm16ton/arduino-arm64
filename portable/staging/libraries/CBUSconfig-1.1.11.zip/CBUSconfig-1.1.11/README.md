
# Arduino library for MERG CBUS running over CAN bus

## Hardware

## Documentation

See example sketch included with the CBUS library

## License

Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
